use strict;
use warnings;
package Test::WithSetup::Command;
use App::Cmd::Setup -command;
1;
